<div class="container-fluid">
    <footer class="row mx-auto tm-footer">
        <div class="col-md-6 px-0">
            Copyright 2024 Basara Migmar-Dolma Limited. All rights reserved.
        </div>
        <div class="col-md-6 px-0 tm-footer-right">
            Designed by <a rel="sponsored" href="https://templatemo.com" target="_blank" class="tm-link-white">Dolma</a>
        </div>
    </footer>
</div>
</div>
<!-- Preloader, https://ihatetomatoes.net/create-custom-preloading-screen/ -->

<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/slick.js"></script>
<script src="../js/templatemo-script.js"></script>
<script src="../js/myjs.js"></script>

</body>

</html>